﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace UcBank
{
    public partial class Form1 : Form
    {
        DataTable users = new DataTable();
        int id = 0;
        int saldo = 0;
        int depositAmount = 0;
        int withdrawalAmount = 0;
        public Form1()
        {
            InitializeComponent();

            // inisialisasi kolom data table
            users.Columns.Add("username");
            users.Columns.Add("password");
            users.Columns.Add("saldo");

            // hide register panel
            registerPanel.Visible = false;
            panelDeposit.Visible = false;
            panelWithdraw.Visible = false;
            balancePanel.Visible = false;
        }

        private void registerButtonLogin_Click(object sender, EventArgs e)
        {
            // ganti ke panel register
            loginPanel.Visible = false;
            registerPanel.Visible = true;

            // hapus text input username dan password di panel login
            usernameInputLogin.Text = "";
            passwordInputLogin.Text = "";
        }

        private void registerButtonRegister_Click(object sender, EventArgs e)
        {
            // cek kalo username atau password empty
            if (String.IsNullOrEmpty(usernameInputRegister.Text) || String.IsNullOrEmpty(passwordInputRegister.Text))
            {
                // kalo empty tunjukkan error message
                MessageBox.Show("Username and password must not be empty!");
            } else
            {
                // kalau tidak emtpy, cek apakah ada yang sama usernamenya atau tidak dengan input
                bool usernameExists = false;

                foreach (DataRow user in users.Rows)
                {
                    if (user["username"].ToString() == usernameInputRegister.Text)
                    {
                        usernameExists = true;
                        break;
                    }
                }

                // kalau tidak ada username yang sama, tambah user baru
                if (usernameExists == false)
                {
                    DataRow user = users.NewRow();
                    user["username"] = usernameInputRegister.Text;
                    user["password"] = passwordInputRegister.Text;
                    user["saldo"] = 0;
                    users.Rows.Add(user);

                    // pindah ke panel login
                    registerPanel.Visible = false;
                    loginPanel.Visible = true;

                } else
                {
                    MessageBox.Show("Username has already existed! Please make another one!");
                }

                // hapus isi input text
                usernameInputRegister.Text = "";
                passwordInputRegister.Text = "";

                usernameExists = false;
            }
        }

        private void loginButtonLogin_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(usernameInputLogin.Text) || String.IsNullOrEmpty(passwordInputLogin.Text))
            {                
                MessageBox.Show("Username and password must not be empty!");
            }
            else
            {                
                bool userExists = false;

                foreach (DataRow user in users.Rows)
                {
                    if (user["username"].ToString() == usernameInputLogin.Text && user["password"].ToString() == passwordInputLogin.Text)
                    {
                        userExists = true; 
                        break;
                    }
                }

                // kalo ada, maka login sukses
                if (userExists == true)
                {                 
                    MessageBox.Show("Login Successful!");
                    balancePanel.Visible = true;
                    loginPanel.Visible = false;
                    balanceLabel.Text = Convert.ToString(saldo.ToString("C2").Remove(1, 0));


                } else
                {
                    MessageBox.Show("Username or password is invalid!");
                    userExists = false;                    
                }
                usernameInputLogin.Text = "";
                passwordInputLogin.Text = "";
            }
        }

        private void depositButton_Click(object sender, EventArgs e)
        {            
            panelDeposit.Visible = true;
            panelWithdraw.Visible = false;
            loginPanel.Visible = false;
            balancePanel.Visible = false;
            registerPanel.Visible = false;           
        }

        private void depositButtonDeposit_Click(object sender, EventArgs e)
        {            
            depositAmount = Convert.ToInt32(tbDepositAmount.Text);
            saldo += depositAmount;
            tbDepositAmount.Text = "";

            panelDeposit.Visible = false;
            panelWithdraw.Visible = false;
            loginPanel.Visible = false;
            balancePanel.Visible = true;
            registerPanel.Visible = false;
           
            balanceLabel.Text = Convert.ToString(saldo.ToString("C2").Remove(1,0));
        }

        private void withdrawButton_Click(object sender, EventArgs e)
        {
            panelDeposit.Visible = false;
            panelWithdraw.Visible = true;
            loginPanel.Visible = false;
            balancePanel.Visible = false;
            registerPanel.Visible = false;
            balanceLabelWithdraw.Text = Convert.ToString(saldo.ToString("C2").Remove(1, 0));
        }

        private void withdrawButtonWithdraw_Click(object sender, EventArgs e)
        {
            withdrawalAmount = Convert.ToInt32(tbWithdrawAmount.Text);
            if (withdrawalAmount > saldo)
            {
                MessageBox.Show("Balance tidak cukup");
            }
            else
            {               
                saldo -= withdrawalAmount;
                tbWithdrawAmount.Text = "";

                panelDeposit.Visible = false;
                panelWithdraw.Visible = false;
                loginPanel.Visible = false;
                balancePanel.Visible = true;
                registerPanel.Visible = false;

                balanceLabelWithdraw.Text = Convert.ToString(saldo.ToString("C2").Remove(1,0));
                balanceLabel.Text = Convert.ToString(saldo.ToString("C2").Remove(1, 0));
            }
            
        }

        private void logoutButtonWithdraw_Click(object sender, EventArgs e)
        {           
            panelDeposit.Visible = false;
            panelWithdraw.Visible = false;
            loginPanel.Visible = true;
            balancePanel.Visible = false;
            registerPanel.Visible = false;
        }

        private void logOutButtonDeposit_Click(object sender, EventArgs e)
        {
            panelDeposit.Visible = false;
            panelWithdraw.Visible = false;
            loginPanel.Visible = true;
            balancePanel.Visible = false;
            registerPanel.Visible = false;
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            panelDeposit.Visible = false;
            panelWithdraw.Visible = false;
            loginPanel.Visible = true;
            balancePanel.Visible = false;
            registerPanel.Visible = false;
        }

        //private string formatString()
        //{

        //}
    }
}
