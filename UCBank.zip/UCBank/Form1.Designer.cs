﻿namespace UcBank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.registerButtonLogin = new System.Windows.Forms.Button();
            this.loginPanel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.passwordInputLogin = new System.Windows.Forms.TextBox();
            this.usernameInputLogin = new System.Windows.Forms.TextBox();
            this.loginButtonLogin = new System.Windows.Forms.Button();
            this.registerPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordInputRegister = new System.Windows.Forms.TextBox();
            this.usernameInputRegister = new System.Windows.Forms.TextBox();
            this.registerButtonRegister = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.title = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.balanceLabel = new System.Windows.Forms.Label();
            this.depositButton = new System.Windows.Forms.Button();
            this.withdrawButton = new System.Windows.Forms.Button();
            this.balancePanel = new System.Windows.Forms.Panel();
            this.LogOutButton = new System.Windows.Forms.Button();
            this.tbDepositAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.depositButtonDeposit = new System.Windows.Forms.Button();
            this.panelDeposit = new System.Windows.Forms.Panel();
            this.logOutButtonDeposit = new System.Windows.Forms.Button();
            this.panelWithdraw = new System.Windows.Forms.Panel();
            this.balanceLabelWithdraw = new System.Windows.Forms.Label();
            this.logoutButtonWithdraw = new System.Windows.Forms.Button();
            this.withdrawButtonWithdraw = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tbWithdrawAmount = new System.Windows.Forms.TextBox();
            this.loginPanel.SuspendLayout();
            this.registerPanel.SuspendLayout();
            this.balancePanel.SuspendLayout();
            this.panelDeposit.SuspendLayout();
            this.panelWithdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // registerButtonLogin
            // 
            this.registerButtonLogin.Location = new System.Drawing.Point(156, 175);
            this.registerButtonLogin.Margin = new System.Windows.Forms.Padding(4);
            this.registerButtonLogin.Name = "registerButtonLogin";
            this.registerButtonLogin.Size = new System.Drawing.Size(100, 28);
            this.registerButtonLogin.TabIndex = 0;
            this.registerButtonLogin.Text = "Register";
            this.registerButtonLogin.UseVisualStyleBackColor = true;
            this.registerButtonLogin.Click += new System.EventHandler(this.registerButtonLogin_Click);
            // 
            // loginPanel
            // 
            this.loginPanel.Controls.Add(this.label3);
            this.loginPanel.Controls.Add(this.label2);
            this.loginPanel.Controls.Add(this.passwordInputLogin);
            this.loginPanel.Controls.Add(this.usernameInputLogin);
            this.loginPanel.Controls.Add(this.loginButtonLogin);
            this.loginPanel.Controls.Add(this.registerButtonLogin);
            this.loginPanel.Location = new System.Drawing.Point(38, 75);
            this.loginPanel.Margin = new System.Windows.Forms.Padding(4);
            this.loginPanel.Name = "loginPanel";
            this.loginPanel.Size = new System.Drawing.Size(351, 227);
            this.loginPanel.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Username";
            // 
            // passwordInputLogin
            // 
            this.passwordInputLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordInputLogin.Location = new System.Drawing.Point(156, 75);
            this.passwordInputLogin.Name = "passwordInputLogin";
            this.passwordInputLogin.Size = new System.Drawing.Size(166, 27);
            this.passwordInputLogin.TabIndex = 3;
            // 
            // usernameInputLogin
            // 
            this.usernameInputLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameInputLogin.Location = new System.Drawing.Point(156, 42);
            this.usernameInputLogin.Name = "usernameInputLogin";
            this.usernameInputLogin.Size = new System.Drawing.Size(166, 27);
            this.usernameInputLogin.TabIndex = 2;
            // 
            // loginButtonLogin
            // 
            this.loginButtonLogin.Location = new System.Drawing.Point(156, 139);
            this.loginButtonLogin.Margin = new System.Windows.Forms.Padding(4);
            this.loginButtonLogin.Name = "loginButtonLogin";
            this.loginButtonLogin.Size = new System.Drawing.Size(100, 28);
            this.loginButtonLogin.TabIndex = 1;
            this.loginButtonLogin.Text = "Login";
            this.loginButtonLogin.UseVisualStyleBackColor = true;
            this.loginButtonLogin.Click += new System.EventHandler(this.loginButtonLogin_Click);
            // 
            // registerPanel
            // 
            this.registerPanel.Controls.Add(this.label1);
            this.registerPanel.Controls.Add(this.label4);
            this.registerPanel.Controls.Add(this.passwordInputRegister);
            this.registerPanel.Controls.Add(this.usernameInputRegister);
            this.registerPanel.Controls.Add(this.registerButtonRegister);
            this.registerPanel.Location = new System.Drawing.Point(38, 75);
            this.registerPanel.Margin = new System.Windows.Forms.Padding(4);
            this.registerPanel.Name = "registerPanel";
            this.registerPanel.Size = new System.Drawing.Size(446, 182);
            this.registerPanel.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Username";
            // 
            // passwordInputRegister
            // 
            this.passwordInputRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordInputRegister.Location = new System.Drawing.Point(156, 75);
            this.passwordInputRegister.Name = "passwordInputRegister";
            this.passwordInputRegister.Size = new System.Drawing.Size(166, 27);
            this.passwordInputRegister.TabIndex = 3;
            // 
            // usernameInputRegister
            // 
            this.usernameInputRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameInputRegister.Location = new System.Drawing.Point(156, 42);
            this.usernameInputRegister.Name = "usernameInputRegister";
            this.usernameInputRegister.Size = new System.Drawing.Size(166, 27);
            this.usernameInputRegister.TabIndex = 2;
            // 
            // registerButtonRegister
            // 
            this.registerButtonRegister.Location = new System.Drawing.Point(156, 139);
            this.registerButtonRegister.Margin = new System.Windows.Forms.Padding(4);
            this.registerButtonRegister.Name = "registerButtonRegister";
            this.registerButtonRegister.Size = new System.Drawing.Size(100, 28);
            this.registerButtonRegister.TabIndex = 0;
            this.registerButtonRegister.Text = "Register";
            this.registerButtonRegister.UseVisualStyleBackColor = true;
            this.registerButtonRegister.Click += new System.EventHandler(this.registerButtonRegister_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // title
            // 
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(154, 23);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(181, 38);
            this.title.TabIndex = 1;
            this.title.Text = "UC Bank";
            this.title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Balance";
            // 
            // balanceLabel
            // 
            this.balanceLabel.AutoSize = true;
            this.balanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceLabel.Location = new System.Drawing.Point(109, 90);
            this.balanceLabel.Name = "balanceLabel";
            this.balanceLabel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.balanceLabel.Size = new System.Drawing.Size(129, 36);
            this.balanceLabel.TabIndex = 8;
            this.balanceLabel.Text = "Rp. 0,00";
            // 
            // depositButton
            // 
            this.depositButton.Location = new System.Drawing.Point(124, 138);
            this.depositButton.Name = "depositButton";
            this.depositButton.Size = new System.Drawing.Size(93, 29);
            this.depositButton.TabIndex = 9;
            this.depositButton.Text = "Deposit";
            this.depositButton.UseVisualStyleBackColor = true;
            this.depositButton.Click += new System.EventHandler(this.depositButton_Click);
            // 
            // withdrawButton
            // 
            this.withdrawButton.Location = new System.Drawing.Point(124, 173);
            this.withdrawButton.Name = "withdrawButton";
            this.withdrawButton.Size = new System.Drawing.Size(93, 30);
            this.withdrawButton.TabIndex = 10;
            this.withdrawButton.Text = "Withdraw";
            this.withdrawButton.UseVisualStyleBackColor = true;
            this.withdrawButton.Click += new System.EventHandler(this.withdrawButton_Click);
            // 
            // balancePanel
            // 
            this.balancePanel.Controls.Add(this.LogOutButton);
            this.balancePanel.Controls.Add(this.balanceLabel);
            this.balancePanel.Controls.Add(this.withdrawButton);
            this.balancePanel.Controls.Add(this.label5);
            this.balancePanel.Controls.Add(this.depositButton);
            this.balancePanel.Location = new System.Drawing.Point(56, 74);
            this.balancePanel.Name = "balancePanel";
            this.balancePanel.Size = new System.Drawing.Size(382, 248);
            this.balancePanel.TabIndex = 11;
            // 
            // LogOutButton
            // 
            this.LogOutButton.Location = new System.Drawing.Point(273, 25);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(75, 30);
            this.LogOutButton.TabIndex = 11;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // tbDepositAmount
            // 
            this.tbDepositAmount.Location = new System.Drawing.Point(54, 138);
            this.tbDepositAmount.Name = "tbDepositAmount";
            this.tbDepositAmount.Size = new System.Drawing.Size(116, 22);
            this.tbDepositAmount.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Input Deposit Amount";
            // 
            // depositButtonDeposit
            // 
            this.depositButtonDeposit.Location = new System.Drawing.Point(74, 180);
            this.depositButtonDeposit.Name = "depositButtonDeposit";
            this.depositButtonDeposit.Size = new System.Drawing.Size(75, 29);
            this.depositButtonDeposit.TabIndex = 12;
            this.depositButtonDeposit.Text = "Deposit";
            this.depositButtonDeposit.UseVisualStyleBackColor = true;
            this.depositButtonDeposit.Click += new System.EventHandler(this.depositButtonDeposit_Click);
            // 
            // panelDeposit
            // 
            this.panelDeposit.Controls.Add(this.logOutButtonDeposit);
            this.panelDeposit.Controls.Add(this.depositButtonDeposit);
            this.panelDeposit.Controls.Add(this.label6);
            this.panelDeposit.Controls.Add(this.tbDepositAmount);
            this.panelDeposit.Location = new System.Drawing.Point(59, 60);
            this.panelDeposit.Name = "panelDeposit";
            this.panelDeposit.Size = new System.Drawing.Size(388, 262);
            this.panelDeposit.TabIndex = 13;
            // 
            // logOutButtonDeposit
            // 
            this.logOutButtonDeposit.Location = new System.Drawing.Point(176, 39);
            this.logOutButtonDeposit.Name = "logOutButtonDeposit";
            this.logOutButtonDeposit.Size = new System.Drawing.Size(75, 30);
            this.logOutButtonDeposit.TabIndex = 12;
            this.logOutButtonDeposit.Text = "Log Out";
            this.logOutButtonDeposit.UseVisualStyleBackColor = true;
            this.logOutButtonDeposit.Click += new System.EventHandler(this.logOutButtonDeposit_Click);
            // 
            // panelWithdraw
            // 
            this.panelWithdraw.Controls.Add(this.balanceLabelWithdraw);
            this.panelWithdraw.Controls.Add(this.logoutButtonWithdraw);
            this.panelWithdraw.Controls.Add(this.withdrawButtonWithdraw);
            this.panelWithdraw.Controls.Add(this.label7);
            this.panelWithdraw.Controls.Add(this.tbWithdrawAmount);
            this.panelWithdraw.Location = new System.Drawing.Point(83, 60);
            this.panelWithdraw.Name = "panelWithdraw";
            this.panelWithdraw.Size = new System.Drawing.Size(352, 293);
            this.panelWithdraw.TabIndex = 14;
            // 
            // balanceLabelWithdraw
            // 
            this.balanceLabelWithdraw.AutoSize = true;
            this.balanceLabelWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceLabelWithdraw.Location = new System.Drawing.Point(39, 59);
            this.balanceLabelWithdraw.Name = "balanceLabelWithdraw";
            this.balanceLabelWithdraw.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.balanceLabelWithdraw.Size = new System.Drawing.Size(129, 36);
            this.balanceLabelWithdraw.TabIndex = 12;
            this.balanceLabelWithdraw.Text = "Rp. 0,00";
            // 
            // logoutButtonWithdraw
            // 
            this.logoutButtonWithdraw.Location = new System.Drawing.Point(214, 19);
            this.logoutButtonWithdraw.Name = "logoutButtonWithdraw";
            this.logoutButtonWithdraw.Size = new System.Drawing.Size(75, 30);
            this.logoutButtonWithdraw.TabIndex = 12;
            this.logoutButtonWithdraw.Text = "Log Out";
            this.logoutButtonWithdraw.UseVisualStyleBackColor = true;
            this.logoutButtonWithdraw.Click += new System.EventHandler(this.logoutButtonWithdraw_Click);
            // 
            // withdrawButtonWithdraw
            // 
            this.withdrawButtonWithdraw.Location = new System.Drawing.Point(69, 188);
            this.withdrawButtonWithdraw.Name = "withdrawButtonWithdraw";
            this.withdrawButtonWithdraw.Size = new System.Drawing.Size(88, 29);
            this.withdrawButtonWithdraw.TabIndex = 12;
            this.withdrawButtonWithdraw.Text = "Withdraw";
            this.withdrawButtonWithdraw.UseVisualStyleBackColor = true;
            this.withdrawButtonWithdraw.Click += new System.EventHandler(this.withdrawButtonWithdraw_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Input Withdrawal Amount";
            // 
            // tbWithdrawAmount
            // 
            this.tbWithdrawAmount.Location = new System.Drawing.Point(49, 146);
            this.tbWithdrawAmount.Name = "tbWithdrawAmount";
            this.tbWithdrawAmount.Size = new System.Drawing.Size(125, 22);
            this.tbWithdrawAmount.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 375);
            this.Controls.Add(this.panelWithdraw);
            this.Controls.Add(this.balancePanel);
            this.Controls.Add(this.panelDeposit);
            this.Controls.Add(this.registerPanel);
            this.Controls.Add(this.title);
            this.Controls.Add(this.loginPanel);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.loginPanel.ResumeLayout(false);
            this.loginPanel.PerformLayout();
            this.registerPanel.ResumeLayout(false);
            this.registerPanel.PerformLayout();
            this.balancePanel.ResumeLayout(false);
            this.balancePanel.PerformLayout();
            this.panelDeposit.ResumeLayout(false);
            this.panelDeposit.PerformLayout();
            this.panelWithdraw.ResumeLayout(false);
            this.panelWithdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button registerButtonLogin;
        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.Button loginButtonLogin;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox passwordInputLogin;
        private System.Windows.Forms.TextBox usernameInputLogin;
        private System.Windows.Forms.Panel registerPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox passwordInputRegister;
        private System.Windows.Forms.TextBox usernameInputRegister;
        private System.Windows.Forms.Button registerButtonRegister;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label balanceLabel;
        private System.Windows.Forms.Button depositButton;
        private System.Windows.Forms.Button withdrawButton;
        private System.Windows.Forms.Panel balancePanel;
        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.TextBox tbDepositAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button depositButtonDeposit;
        private System.Windows.Forms.Panel panelDeposit;
        private System.Windows.Forms.Button logOutButtonDeposit;
        private System.Windows.Forms.Panel panelWithdraw;
        private System.Windows.Forms.Button logoutButtonWithdraw;
        private System.Windows.Forms.Button withdrawButtonWithdraw;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbWithdrawAmount;
        private System.Windows.Forms.Label balanceLabelWithdraw;
    }
}

